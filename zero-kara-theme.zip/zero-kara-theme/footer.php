<?php if (!defined('ABSPATH')) exit; ?>
<?php if(zk_value('privacy_url') || zk_value('legal_url') || zk_value('terms_url') || zk_value('operator')): ?><footer class="site-footer"><nav aria-label="フッター"><?php foreach(array('privacy_url'=>'プライバシーポリシー','legal_url'=>'特定商取引法に基づく表記','terms_url'=>'利用規約') as $key=>$label) { $url=zk_url(zk_value($key)); if($url) echo '<a href="'.esc_url($url).'">'.esc_html($label).'</a>'; } ?></nav><?php if(zk_value('operator')): ?><p><?php zk_text('operator'); ?></p><?php endif; ?></footer><?php endif; ?>
</div><?php wp_footer(); ?></body></html>
