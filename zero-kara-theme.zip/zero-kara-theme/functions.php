<?php
/** Zero Kara LP — no external plugins required. */
if (!defined('ABSPATH')) { exit; }
function zk_sections() { static $data; if ($data === null) { $data = json_decode(file_get_contents(__DIR__ . '/content.json'), true); } return $data; }
function zk_profile_default() { return trim(file_get_contents(__DIR__ . '/profile.txt')); }
function zk_line_default() { return 'https://liff-gateway.lineml.jp/landing?follow=%40937esffm&lp=yQOLtD&liff_id=2011901939-BjWOunBz'; }
function zk_youtube_id() {
    $url=zk_url(zk_value('youtube_video_url'));
    $host=strtolower(wp_parse_url($url, PHP_URL_HOST) ?: '');
    $path=wp_parse_url($url, PHP_URL_PATH) ?: '';
    $id='';
    if ($host==='youtu.be') $id=trim($path,'/');
    elseif (in_array($host,array('youtube.com','www.youtube.com','m.youtube.com','www.youtube-nocookie.com'),true)) {
        if (preg_match('~^/(?:embed|shorts)/([A-Za-z0-9_-]{11})$~',$path,$match)) $id=$match[1];
        else { parse_str(wp_parse_url($url,PHP_URL_QUERY) ?: '',$query); $id=$query['v'] ?? ''; }
    }
    return is_string($id) && preg_match('/^[A-Za-z0-9_-]{11}$/D',$id) ? $id : '';
}
function zk_value($key, $default = '') { if ($key==='line_url' && $default==='') $default=zk_line_default(); if ($key==='youtube_video_url' && $default==='') $default='https://youtu.be/H32BiIpkgKg'; if ($key === 'profile' && $default === '') { $default = zk_profile_default(); } return get_theme_mod('zk_' . $key, $default); }
function zk_text($key, $default = '') {
    $text = esc_html(zk_value($key, $default));
    $markers = array(
        'hero_title'=>'資産形成は後回し？',
        'hero_tagline'=>'稼ぐの次は、増やすチカラを。',
        'empathy_title'=>'なのに、何を選べばいいかは分からない。',
        'problem_quote'=>'「どう判断するか」を学ぶ。',
        'movie_title'=>'まずは動画でご覧ください。',
        'before-after_title'=>'自分のお金を自分で決められる人。',
        'founder_name'=>'主宰｜アンナ社長',
        'service_title'=>'投資を「知識」で終わらせない3つの環境。',
        'final_quote'=>'稼ぐの次は、増やすチカラを。',
    );
    if (isset($markers[$key])) { $phrase=esc_html($markers[$key]); $text=str_replace($phrase,'<mark class="wf-marker">'.$phrase.'</mark>',$text); }
    // Preserve wording while keeping meaningful Japanese phrases together.
    $heading_chunks = array(
        'empathy_title'=>array('なのに、','何を選べばいいかは','分からない。'),
        'gap_title'=>array('稼ぐことは','学んできた。','でも、','「増やすこと」は','誰も','教えてくれなかった。'),
        'problem_title'=>array('必要なのは、','「おすすめの投資先」を','増やすことでは','ありません。'),
        'about_title'=>array('自分のお金は、','自分で判断できる','ようになる。'),
        'movie_title'=>array('ゼロから','投資アカデミーとは？','まずは動画で','ご覧ください。'),
        'before-after_title'=>array('目指すのは、','投資に詳しい人ではなく、','自分のお金を','自分で決められる人。'),
        'recommendation_title'=>array('経営の第一線に','いる人たちが、','アンナ社長を','推薦する理由。'),
        'service_title'=>array('知る。','考える。','実践する。','投資を「知識」で','終わらせない','3つの環境。'),
        'themes_title'=>array('例えば、','こんな疑問を','自分で考えられる','ようになるために。'),
        'guest_title'=>array('直近の','ゲストセッション'),
        'inside_title'=>array('「どんな場所なの？」を、','入会前に','少しだけ。'),
        'for-you_title'=>array('こんな方のための','アカデミーです。'),
        'membership_title'=>array('投資について','考える環境を、','1年間の日常に。'),
        'final_title'=>array('1年後も、','「そろそろ投資、','ちゃんと勉強しないとな」','と言っていたくない人へ。'),
        'service_cards_0_title'=>array('「何を買うか」ではなく、','「どう考えるか」を','学ぶ。'),
        'service_cards_1_title'=>array('成功した結果ではなく、','「どう判断したか」を','聞く。'),
        'service_cards_2_title'=>array('お金の話を、','普通にできる','仲間がいる。')
    );
    // Split markup first so marker tags and escaped user input remain intact.
    $parts=preg_split('/(<[^>]+>)/u',$text,-1,PREG_SPLIT_DELIM_CAPTURE);
    foreach($parts as &$part) {
        if ($part === '' || $part[0] === '<') continue;
        if (isset($heading_chunks[$key])) {
            $phrases=array_map('esc_html',$heading_chunks[$key]);
            $pattern='/('.implode('|',array_map(function($p){return preg_quote($p,'/');},$phrases)).')/u';
            $part=preg_replace($pattern,'<span class="jp-phrase">$1</span>',$part);
        } else {
            $part=preg_replace('/[ァ-ヺー]{2,}/u','<span class="jp-word">$0</span>',$part);
        }
    }
    unset($part);
    echo nl2br(implode('',$parts));
}
function zk_draft() { return (bool) zk_value('draft', true); }
function zk_url($value) { $url = esc_url_raw($value, array('https')); return strpos($url, 'https://') === 0 ? $url : ''; }
function zk_assets() {
    $version = wp_get_theme()->get('Version');
    wp_enqueue_style('zero-kara', get_stylesheet_uri(), array(), $version);
    wp_enqueue_script('zero-kara', get_template_directory_uri() . '/assets/site.js', array(), $version, array('in_footer'=>true, 'strategy'=>'defer'));
}
add_action('wp_enqueue_scripts', 'zk_assets');
add_action('after_setup_theme', function () { add_theme_support('title-tag'); add_theme_support('post-thumbnails'); add_theme_support('responsive-embeds'); add_theme_support('html5', array('style','script')); });
add_filter('wp_robots', function ($robots) { if (zk_draft()) { $robots['noindex'] = true; $robots['nofollow'] = true; } return $robots; });
function zk_images() {
    $images = array('hero'=>'FV：アンナ社長','founder'=>'主宰：アンナ社長','before'=>'BEFORE','after'=>'AFTER','recommendation'=>'推薦者','membership-0'=>'講義・ゲスト登壇','membership-1'=>'MOSH投稿・交流');
    foreach (zk_sections() as $s) { if (isset($s['image'])) { $images[$s['id']] = $s['image']; } }
    for ($i=0;$i<3;$i++) { $images['service-'.$i] = array('ライブ講義','ゲストセッション','会員限定コミュニティ')[$i]; }
    for ($i=0;$i<2;$i++) { $images['guest-'.$i] = 'ゲスト写真 '.($i+1); }
    for ($i=0;$i<4;$i++) { $images['inside-'.$i] = array('イベント','講義画面','交流会','投稿画面')[$i]; }
    return $images;
}
function zk_visual($key) {
    if ($key !== 'problem') return false;
    echo '<figure class="concept-visual visual-problem" aria-label="情報過多を表すビジュアル"><div class="concept-chips"><span>NISA</span><span>株</span><span>不動産</span><span>海外投資</span></div></figure>';
    return true;
}
function zk_generated_media($key, $class='') {
    $map=array(
      'problem'=>array('information-overload-simple','スマホに並ぶNISA・株・不動産・海外投資と、SNS・動画・ニュースの情報に迷う人のイラスト'),
      'empathy'=>array('empathy-natural-v2','投資情報を見ながら考えるイメージ'),
      'gap'=>array('work-decision-male','仕事で意思決定するイメージ'),
      'about'=>array('about-anna-lecture','投資について学ぶイメージ'),
      'before'=>array('before-simple','情報を前に迷うイメージ'),
      'after'=>array('after-asset-planning','資産配分と将来の計画を整理する人のイラスト'),
      'service-0'=>array('learning-lecture','オンラインで学ぶイメージ'),
      'service-1'=>array('guest-audience-session','実践者との対話イメージ'),
      'service-2'=>array('community-photo-v2','仲間と学ぶイメージ'),
      'themes'=>array('themes-materials','講義・教材のイメージ'),
      'flow'=>array('flow-phone','申し込みのイメージ'),
      'guest-1'=>array('decision','ゲストセッションのイメージ'),
      'inside-1'=>array('about-anna-lecture','オンラインで投資について学ぶイメージ'),
      'inside-3'=>array('inside-post-bright','交流のイメージ'),
      'guest-0'=>array('real-estate','海外不動産のテーマイメージ'),
      'inside-0'=>array('inside-event','学びのイメージ'),
      'inside-2'=>array('inside-conversation','交流のイメージ'),
      'for-you'=>array('for-you-bright','仕事と資産形成を考えるイメージ'),
      'membership-0'=>array('membership-anna-seminar','講演会で笑顔を見せるアンナ社長'),
      'membership-1'=>array('membership-exchange-bright','共に考えるイメージ')
    );
    if (!isset($map[$key])) return false;
    [$file,$label]=$map[$key];
    echo '<figure class="generated-media '.esc_attr($class).'"><div class="generated-image"><img src="'.esc_url(get_template_directory_uri().'/assets/generated/'.$file.'.png').'" width="1672" height="941" alt="'.esc_attr($label).'" loading="lazy" decoding="async"></div></figure>';
    return true;
}
function zk_media($key, $label, $class = '') {
    $id = absint(zk_value('image_'.$key, 0));
    if ($id && wp_attachment_is_image($id)) {
        echo '<figure class="media '.esc_attr($class).'">';
        echo wp_get_attachment_image($id, 'large', false, array('alt'=>get_post_meta($id,'_wp_attachment_image_alt',true) ?: $label, 'loading'=>$key==='hero'?'eager':'lazy', 'fetchpriority'=>$key==='hero'?'high':'auto'));
        echo '</figure>';
    } elseif (in_array($key, array('guest-0','guest-1'), true)) {
        $guest = $key === 'guest-0' ? array('cutouts/soyano-neutral.png','征矢野さん',1334,1179) : array('cutouts/sugawara.png','脱・税理士スガワラくん（菅原由一）',1044,1507);
        echo '<figure class="guest-portrait portrait-'.esc_attr($key).'"><img src="'.esc_url(get_template_directory_uri().'/assets/'.$guest[0]).'" width="'.$guest[2].'" height="'.$guest[3].'" alt="'.esc_attr($guest[1]).'" loading="lazy" decoding="async"></figure>';
    } elseif (in_array($key,array('about','membership-1'),true)) {
        $photo=$key==='about' ? array('about-anna-real.jpg','笑顔で資料を説明するアンナ社長') : array('membership-dialogue-real.jpg','資料を見ながら対話するアンナ社長');
        echo '<figure class="media supplied-learning"><img src="'.esc_url(get_template_directory_uri().'/assets/'.$photo[0]).'" width="1980" height="1320" alt="'.esc_attr($photo[1]).'" loading="lazy" decoding="async"></figure>';
    } elseif (in_array($key,array('inside-0','inside-2'),true)) {
        $photo=$key==='inside-0'?array('inside-seminar-private.jpg','アンナ社長による実際の講演会の様子',4032,3024):array('inside-dinner-private.jpg','実際の会食で話すアンナ社長',3520,1980);
        echo '<figure class="media supplied-event"><img src="'.esc_url(get_template_directory_uri().'/assets/'.$photo[0]).'" width="'.$photo[2].'" height="'.$photo[3].'" alt="'.esc_attr($photo[1]).'" loading="lazy" decoding="async"></figure>';
    } elseif ($key === 'flow') {
        echo '<figure class="media flow-photo"><img src="'.esc_url(get_template_directory_uri().'/assets/flow-supplied.png').'" width="1536" height="1024" alt="スマートフォンを操作する女性" loading="lazy" decoding="async"></figure>';
    } elseif ($key === 'final') {
        echo '<figure class="media final-photo"><img src="'.esc_url(get_template_directory_uri().'/assets/anna-final.png').'" width="1500" height="1000" alt="会議で話すアンナ社長" loading="lazy" decoding="async"></figure>';
    } elseif (in_array($key, array('hero', 'founder'), true)) {
        echo '<figure class="media bundled-portrait portrait-'.esc_attr($key).' '.esc_attr($class).'">';
        echo '<img src="'.esc_url(get_template_directory_uri().'/assets/'.($key==='hero'?'cutouts/anna-hero-no-earring.png':'cutouts/anna-founder-0433.png')).'" width="1023" height="1537" alt="荒木杏奈（アンナ社長）" loading="'.($key==='hero'?'eager':'lazy').'" fetchpriority="'.($key==='hero'?'high':'auto').'" decoding="async">';
        echo '</figure>';
    } elseif (zk_generated_media($key, $class) || zk_visual($key)) {
        return;
    } elseif ($key === 'recommendation') {
        return;
    } elseif (zk_draft()) {
        echo '<figure class="media placeholder '.esc_attr($class).'" aria-label="'.esc_attr($label.'：素材未提供').'">';
        echo '<span class="placeholder-symbol" aria-hidden="true">0<span>↗</span></span><figcaption><span>PHOTO / 素材待ち</span><strong>'.esc_html($label).'</strong></figcaption></figure>';
    }
}
function zk_line_icon($inline=false) {
    $file=$inline ? 'line-icon-inline-white.webp' : 'line-icon-deep-green.webp';
    return '<img class="line-logo-image" src="'.esc_url(get_template_directory_uri().'/assets/optimized/'.$file).'" width="160" height="160" alt="" aria-hidden="true" decoding="async">';
}
function zk_cta($label='LINEで入会案内を受け取る', $location='body') {
    $url=zk_url(zk_value('line_url'));
    if ($url) { echo '<a class="cta" href="'.esc_url($url).'" data-cta="'.esc_attr($location).'" target="_blank" rel="noopener noreferrer"><span class="line-icon" aria-hidden="true">'.zk_line_icon(true).'</span><span>'.esc_html($label).'</span><span aria-hidden="true">↗</span></a>'; }
    else { echo '<button class="cta" type="button" disabled><span class="line-icon" aria-hidden="true">'.zk_line_icon(true).'</span><span>'.esc_html($label).'</span><span aria-hidden="true">↗</span></button>'; }
}
function zk_sticky_cta() {
    $url=zk_url(zk_value('line_url'));
    echo '<div class="sticky-line-bar" role="region" aria-label="LINE入会案内">';
    if ($url) echo '<a class="sticky-line-link" href="'.esc_url($url).'" data-cta="sticky" target="_blank" rel="noopener noreferrer">';
    else echo '<button class="sticky-line-link" type="button" disabled>';
    echo '<span class="sticky-line-icon" aria-hidden="true">'.zk_line_icon().'</span><span class="sticky-line-copy"><strong>入会案内を受け取る</strong></span><span class="sticky-line-arrow" aria-hidden="true"><svg viewBox="0 0 24 24" width="24" height="24" focusable="false"><path d="M5 12h14M12 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span>';
    echo $url ? '</a>' : '</button>';
    echo '</div>';
}
function zk_list($s, $field='checks', $negative=false) {
    echo '<ul class="check-list'.($negative?' negative':'').'">';
    foreach ($s[$field] as $i=>$item) { echo '<li>'; zk_text($s['id'].'_'.$field.'_'.$i, $item); echo '</li>'; }
    echo '</ul>';
}
function zk_register_fields($c, $value, $path, $section) {
    foreach ($value as $key=>$item) {
        if (in_array($key, array('id','kind','en','image'),true)) { continue; }
        $name=$path.'_'.$key;
        if (is_array($item)) { zk_register_fields($c,$item,$name,$section); continue; }
        $c->add_setting('zk_'.$name,array('default'=>$item,'sanitize_callback'=>'sanitize_textarea_field'));
        $label=mb_substr($item ?: '未確定テキスト',0,42);
        if (preg_match('/^guest_cards_([0-9]+)_(date|name|role|title|body|profile)$/',$name,$m)) {
            $labels=array('date'=>'開催日時（例：2026.11.6 19:00）','name'=>'登壇者名','role'=>'肩書き','title'=>'イベントタイトル','body'=>'内容・説明','profile'=>'プロフィール');
            $label='イベント'.((int)$m[1]+1).'：'.$labels[$m[2]];
        }
        $c->add_control('zk_'.$name,array('label'=>$label,'section'=>$section,'type'=>'textarea'));
    }
}
add_action('customize_register', function ($c) {
    $c->add_panel('zk_panel',array('title'=>'ゼロから投資 LP設定','priority'=>25));
    $c->add_section('zk_general',array('title'=>'基本設定・リンク','panel'=>'zk_panel'));
    $fields=array(
      'draft'=>array('制作中表示（検索除外・素材待ちの枠を表示）',true,'checkbox'),
      'line_url'=>array('公式LINE URL（https://）',zk_line_default(),'url'),
      'youtube_video_url'=>array('紹介動画 YouTube URL（ページ内再生）','https://youtu.be/H32BiIpkgKg','url'),
      'mosh_video_url'=>array('MOSH動画ページURL（未設定時は公開サイトの05を非表示）','','url'),
      'profile'=>array('主宰プロフィール',zk_profile_default(),'textarea'),
      'recommendation_name'=>array('推薦者氏名・肩書き','','text'),
      'recommendation_quote'=>array('推薦コメント（承認済み原稿）','','textarea'),
      'recommendation_role'=>array('推薦者の会社・関係性','','text'),
      'privacy_url'=>array('プライバシーポリシーURL','','url'),
      'legal_url'=>array('特定商取引法に基づく表記URL','','url'),
      'terms_url'=>array('利用規約URL','','url'),
      'operator'=>array('運営者名','','text'),
      'hero_eyebrow'=>array('FV：肩書き','投資をゼロから学ぶ、会員制投資アカデミー','textarea'),
      'hero_title'=>array('FV：見出し',"年収は上がった。\nでも、資産形成は後回し？",'textarea'),
      'hero_lead'=>array('FV：リード',"投資経験ゼロから、\n自分のお金を、自分で判断できる人へ。",'textarea'),
      'hero_tagline'=>array('FV：タグライン','稼ぐの次は、増やすチカラを。','textarea'),
      'hero_description'=>array('FV：説明','情報に振り回されない、自分なりの判断軸を身につける。','textarea'),
      'registration_note'=>array('LINE補足（運用確定後に入力）','','textarea'),
      'annual_price'=>array('年間料金（税込）',356400,'number'),
      'monthly_price'=>array('月額料金（税込）',33000,'number')
    );
    foreach ($fields as $key=>$f) {
      $san=$f[2]==='url'?'zk_url':($f[2]==='number'?'absint':($f[2]==='checkbox'?'rest_sanitize_boolean':'sanitize_textarea_field'));
      $c->add_setting('zk_'.$key,array('default'=>$f[1],'sanitize_callback'=>$san));
      $c->add_control('zk_'.$key,array('label'=>$f[0],'section'=>'zk_general','type'=>$f[2]));
    }
    $c->add_section('zk_photos',array('title'=>'ロゴ・写真の差し替え','panel'=>'zk_panel'));
    $c->add_setting('zk_logo',array('sanitize_callback'=>'absint'));
    $c->add_control(new WP_Customize_Media_Control($c,'zk_logo',array('label'=>'正式ロゴ（未設定時は提供済みロゴ）','section'=>'zk_photos','mime_type'=>'image')));
    foreach (zk_images() as $key=>$label) {
      if (in_array($key,array('guest-0','guest-1'),true)) continue;
      $c->add_setting('zk_image_'.$key,array('sanitize_callback'=>'absint'));
      $c->add_control(new WP_Customize_Media_Control($c,'zk_image_'.$key,array('label'=>$label,'section'=>'zk_photos','mime_type'=>'image')));
    }
    foreach(zk_sections() as $i=>$s) {
      $section='zk_section_'.$s['id'];
      $c->add_section($section,array('title'=>$s['id']==='guest'?'11 / イベント日程・登壇者':sprintf('%02d / %s',$i+1,$s['en']),'panel'=>'zk_panel'));
      zk_register_fields($c,$s,$s['id'],$section);
      if ($s['id']==='guest') foreach($s['cards'] as $j=>$card) {
          $key='zk_image_guest-'.$j;
          $c->add_setting($key,array('sanitize_callback'=>'absint'));
          $c->add_control(new WP_Customize_Media_Control($c,$key,array('label'=>'イベント'.($j+1).'：登壇者写真','section'=>$section,'mime_type'=>'image')));
      }
    }
});

function zk_optimize_images($html) {
    static $manifest;
    if ($manifest === null) $manifest=json_decode(file_get_contents(__DIR__.'/image-manifest.json'),true);
    if (!is_array($manifest)) return $html;
    $base=get_template_directory_uri().'/assets/';
    return preg_replace_callback('/<img\b[^>]*>/i',function($m) use($manifest,$base) {
        $tag=$m[0];
        if(!preg_match('/src="([^"]+)"/',$tag,$src)) return $tag;
        $url=html_entity_decode($src[1],ENT_QUOTES,'UTF-8');
        if(strpos($url,$base)!==0) return $tag;
        $key=substr($url,strlen($base));
        if(!isset($manifest[$key])) return $tag;
        $v=$manifest[$key];$prefix=$base.'optimized/';
        $tag=preg_replace('/\s(?:src|srcset|sizes|width|height)="[^"]*"/','',$tag);
        // Match the actual display slot rather than downloading full-width portraits.
        $sizes='(max-width: 760px) 100vw, 760px';
        if (strpos($tag,'fetchpriority="high"')!==false) $sizes='(max-width: 760px) 43vw, 320px';
        if ($key==='logo.png') $sizes='250px';
        $attrs=' src="'.esc_url($prefix.$v['large']).'" srcset="'.esc_url($prefix.$v['small']).' '.$v['small_width'].'w, '.esc_url($prefix.$v['large']).' '.$v['width'].'w" sizes="'.$sizes.'" width="'.$v['width'].'" height="'.$v['height'].'"';
        return substr($tag,0,-1).$attrs.'>';
    },$html);
}
