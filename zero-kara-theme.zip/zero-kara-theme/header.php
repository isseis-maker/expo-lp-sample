<?php if (!defined('ABSPATH')) exit; ?>
<!doctype html><html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class('zero-kara'); ?>><?php wp_body_open(); ?>
<a class="skip" href="#main">本文へスキップ</a>
<div class="site-shell" id="top">
<?php if(zk_draft()): ?><div class="draft-banner">DESIGN DRAFT <span>内容確認中・公式LINEは準備中です</span></div><?php endif; ?>
<header class="site-header"><a class="brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="ゼロから投資アカデミー ホーム"><?php $logo=absint(zk_value('logo')); if($logo) { echo wp_get_attachment_image($logo,'medium',false,array('alt'=>'ゼロから投資アカデミー')); } else { ?><span class="logo-crop"><img src="<?php echo esc_url(get_template_directory_uri().'/assets/optimized/'.json_decode(file_get_contents(__DIR__.'/image-manifest.json'),true)['logo.png']['small']); ?>" width="6250" height="6250" alt="ゼロから投資アカデミー"></span><?php } ?></a></header>
