<?php if(!defined('ABSPATH')) exit; get_header(); ?>
<main id="main" class="section prose"><?php if(have_posts()): while(have_posts()): the_post(); ?><article><h1><?php the_title(); ?></h1><?php the_content(); ?></article><?php endwhile; the_posts_navigation(); else: ?><h1>ページが見つかりませんでした</h1><p><a href="<?php echo esc_url(home_url('/')); ?>">トップページへ戻る</a></p><?php endif; ?></main>
<?php get_footer(); ?>
