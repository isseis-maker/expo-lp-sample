/* Emits a local browser event only; no analytics service is connected. */
document.querySelectorAll('[data-cta]').forEach((link) => {
  link.addEventListener('click', () => {
    window.dispatchEvent(new CustomEvent('zero-kara:cta', { detail: { location: link.dataset.cta } }));
  });
});

// Hide the browser's video save menu during ordinary interaction.
const introduction = document.querySelector('#introduction-video');
if (introduction) {
  introduction.addEventListener('contextmenu', (event) => event.preventDefault());
}

/* One-time, compositor-friendly entrances; content is visible without JavaScript. */
(() => {
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  if (reduced.matches || !('IntersectionObserver' in window)) return;
  const pending = new Set();
  let observer;
  const reveal = (element, immediate = false) => {
    if (!pending.has(element)) return;
    if (immediate) element.classList.add('zk-instant');
    element.classList.add('zk-visible');
    pending.delete(element);
    observer.unobserve(element);
  };
  const showAll = () => {
    pending.forEach((element) => reveal(element, true));
    observer.disconnect();
    document.documentElement.classList.remove('zk-hero-motion');
  };
  try {
    observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) reveal(entry.target);
      });
    }, { threshold: 0, rootMargin: '0px 0px -24px 0px' });
    // Animate individual blocks, never a tall entire section or nested blocks.
    const selector = '.section > .section-kicker, .section > h2, .section > p, .section > figure, .section > .generated-media, .section > .media-pair:not(.gallery), .section > .statement, .section > .check-list, .section > .profile, .section > .outline-card, .section > .service-card, .section > .guest-card, .section > .price-card, .section > .cta, .gallery > *, .steps > li, .faq';
    const candidates = Array.from(document.querySelectorAll(selector));
    const initialHeight = window.innerHeight;
    candidates.filter((element) => !candidates.some((parent) => parent !== element && parent.contains(element))).forEach((element) => {
      // Leave initial viewport and restored scroll positions immediately readable.
      if (element.getBoundingClientRect().top < initialHeight) return;
      element.classList.add('zk-reveal');
      if (element.matches('figure, .generated-media, .media-pair, .gallery > *')) element.classList.add('zk-reveal-photo');
      pending.add(element);
      observer.observe(element);
    });
    if (window.scrollY < 24 && !location.hash) document.documentElement.classList.add('zk-hero-motion');
    document.addEventListener('focusin', (event) => {
      pending.forEach((element) => { if (element.contains(event.target)) reveal(element, true); });
    });
    const showAnchor = () => {
      let id;
      try { id = decodeURIComponent(location.hash.slice(1)); } catch (_) { return; }
      const target = document.getElementById(id);
      if (target) pending.forEach((element) => {
        if (target.contains(element) || element.contains(target)) reveal(element, true);
      });
    };
    window.addEventListener('hashchange', showAnchor);
    window.addEventListener('beforeprint', showAll);
    window.addEventListener('pageshow', (event) => { if (event.persisted) showAll(); });
    reduced.addEventListener('change', (event) => { if (event.matches) showAll(); });
    showAnchor();
  } catch (_) {
    document.querySelectorAll('.zk-reveal').forEach((element) => element.classList.add('zk-instant', 'zk-visible'));
    if (observer) observer.disconnect();
    document.documentElement.classList.remove('zk-hero-motion');
  }
})();
